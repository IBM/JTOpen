// File to be deleted after full source prime.
